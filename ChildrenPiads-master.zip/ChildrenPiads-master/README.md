# ChildrenPiads


### Purpose
 <p>The purpose of this app is to help evaluate how assistive technologies helps its users. This helps doctors know if the device their patient is using is helping with their therapy or not.</p>
 
### Personas
 <p>This app is designed for patients from ages ranged 5 to 21 that are in the Maryville occupational therapy program.</p>
 
### Goal
  <p>The goal of the app is for the doctor to assess the users performance while they are using the technology, in seeing if it works. This will allow patients to continue with their current treatment or proceed with a better treatment.</p>
  
### About the Developers
  <p>In total there are 3 developers that have worked on this app:</p>
  <i>1. <b>Ayesha Shaik</b></i>
  <p> Ayesha is currently a first year sudent at Maryville university. She is majoring in cyber security and a minor in iOS app development.</p>
  
  <i>2. <b>Cullen Mertens</b></i>
  <p></p>
  <i>3. <b>Aaron Heimberger</b></i>
  <p></p>
